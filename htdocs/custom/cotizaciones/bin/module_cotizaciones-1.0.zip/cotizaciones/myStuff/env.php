<?php
$definite=1;

//$Root = "http://localhost:8888/dolibarr/htdocs/api/index.php/";
$Root = "http://localhost:8888/dolibarr/htdocs/api/index.php/";
//$Root = "https://fontv.online/dolifon/htdocs/api/index.php/";
$Root = "http://localhost:8888/dolibarr/htdocs/api/index.php/";
$Rooo= "http://localhost:8888/dolibarr/htdocs/";




$httpheader =  ['DOLAPIKEY: mAgnV8S8vehYX2Pm3NQ56o46bgXPQu47'];
$httpheader =  ['DOLAPIKEY: oGSKoAlvK86K'];
//$Root = "http://localhost/dolibarr/api/index.php/";


?>
