<?php
$definite=1;
$httpheader =  ['DOLAPIKEY: '];
//$Root = "http://localhost:8888/dolibarr/htdocs/api/index.php/";
$Root = "http://localhost:8888/dolibarr/htdocs/api/index.php/";
//$Root = "https://fontv.online/dolifon/htdocs/api/index.php/";
?>