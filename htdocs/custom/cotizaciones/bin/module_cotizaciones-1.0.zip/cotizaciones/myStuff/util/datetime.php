<?php
$datetime="1656363448";
$mysqltime = date ('Y-m-d', $phptime);

echo $mysqltime;
?>