<?php
print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html class="supernova">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

<!-- You MUST include jQuery before Fomantic -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.3.1/dist/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/fomantic-ui@2.8.8/dist/semantic.min.css">
<script src="https://cdn.jsdelivr.net/npm/fomantic-ui@2.8.8/dist/semantic.min.js"></script>
<script src="js/SorterNico.js"></script>




  <!-- Site Properties -->
  
  
  <style type="text/css">
  h2 {
    margin: 1em 0em;
  }
  .ui.container {
    padding-top: 3em;
    padding-bottom: 3em;
  }
  </style>









    <title>Cotización</title>


  <!-- JavaScript Bundle with Popper -->





'
?>