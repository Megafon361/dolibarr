<?php

/*
$command = "echo 'touch hello.txt' | at now + 1 minutes 2>&1";
$retval = NULL;
$output = NULL;
exec($command, $output, $retval);
//echo "Tiene: ".$output[1];

$job = explode(" ",$output[1]);
echo $job[1];
*/

//echo date("N");

/*
$enlace = mysql_connect('dolibarr.c0nifcnez7db.us-east-1.rds.amazonaws.com', 'DolibarrUser', 'DolibarrPassword');
$res = mysql_query("SHOW DATABASES");

while ($fila = mysql_fetch_assoc($res)) {
    echo $fila['Database'] . "\n";
}
*/

$sql="SHOW DATABASES";
$link = mysqli_connect('dolibarr.c0nifcnez7db.us-east-1.rds.amazonaws.com', 'DolibarrUser', 'DolibarrPassword') or die ('Error connecting to mysql: ' . mysqli_error($link).'\r\n');

if (!($result=mysqli_query($link,$sql))) {
        printf("Error: %s\n", mysqli_error($link));
    }

while( $row = mysqli_fetch_row( $result ) ){
        if (($row[0]!="information_schema") && ($row[0]!="mysql") && ($row[0]!="tmp") && ($row[0]!="innodb") && ($row[0]!="performance_schema")) {
            echo $row[0]."\r\n";
        }
    }

?>
