<?php
// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
dol_include_once('/facturadian/class/facturadian.class.php');
dol_include_once('/facturadian/lib/facturadian_facturadian.lib.php');

// Load translation files required by the page
$langs->loadLangs(array("facturadian@facturadian", "other"));

// Get parameters
$id = GETPOST('id', 'int');
$ref        = GETPOST('ref', 'alpha');
$action = GETPOST('action', 'aZ09');
$confirm    = GETPOST('confirm', 'alpha');
$cancel     = GETPOST('cancel', 'aZ09');
$contextpage = GETPOST('contextpage', 'aZ') ?GETPOST('contextpage', 'aZ') : 'facturadiancard'; // To manage different context of search
$backtopage = GETPOST('backtopage', 'alpha');
$backtopageforcancel = GETPOST('backtopageforcancel', 'alpha');
//$lineid   = GETPOST('lineid', 'int');

// Initialize technical objects
$object = new FacturaDian($db);
$extrafields = new ExtraFields($db);
$diroutputmassaction = $conf->facturadian->dir_output.'/temp/massgeneration/'.$user->id;
$hookmanager->initHooks(array('facturadiancard', 'globalcard')); // Note that conf->hooks_modules contains array


// Load object
include DOL_DOCUMENT_ROOT.'/core/actions_fetchobject.inc.php'; // Must be include, not include_once.

$form = new Form($db);
$formfile = new FormFile($db);
llxHeader('', $langs->trans('FacturaDian'), '');

if ($action == 'create')
{
	print load_fiche_titre($langs->trans("Prefijos Actualizados", $langs->transnoentitiesnoconv("FacturaDian")));

	print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
		dol_fiche_head(array(), '');


		//********************************************************************************
		$sql = "SELECT * FROM ".MAIN_DB_PREFIX."facturadian_facturadianparametros WHERE 1"; 	
		$resql = $db->query($sql);
		if ($resql)
		{
			if($db->num_rows($resql) > 0) {
				$objp = $db->fetch_object($resql);		
				$ejecutar = "php scripts/prefijos.php ".$objp->username." ".$objp->password;
				$respuesta = shell_exec($ejecutar);
				print "<br /><br />".$respuesta;
			}
			$db->free($resql);
		}

		print "<br /><br />";
		print  "<h2>Todos los prefijos actualizados desde la Apps a Dolibarr correctamente...</h2>";
		//********************************************************************************
		
		print '</table>'."\n";

		dol_fiche_end();

	print '</form>';
}

// End of page
llxFooter();
$db->close();
